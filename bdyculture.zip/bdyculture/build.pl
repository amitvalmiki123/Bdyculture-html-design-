#!/usr/bin/perl
# BDYCULTURE inner-page builder.
# Reads src/<page>.html (front matter + body), wraps it with the header, footer,
# Get-in-Touch + map blocks taken from index.html, and writes <page>.html.
# Run:  perl build.pl        (edit src/*.html or index.html, never the generated pages)
use strict; use warnings;

local $/ = undef;
open my $fh, '<:raw', 'index.html' or die $!; my $idx = <$fh>; close $fh;

my ($header) = $idx =~ m{(<a class="skip".*?)<main id="main">}s or die "header";
my ($tail)   = $idx =~ m{(<!-- ============ GET IN TOUCH.*?)</main>}s or die "tail";
my ($after)  = $idx =~ m{</main>(.*</html>)}s or die "after";

my $NOOKAL = 'https://book.nookal.com/bookings/book/EA59F8c8-2593-a0ee-Fbca-FEaEb0d0beE6/select';
my @services = ('Physiotherapy','Exercise Physiology','Occupational Therapy','Clinical Pilates','Home visit enquiry','I&rsquo;m not sure yet');

sub jesc { my $s = shift; $s =~ s/<[^>]+>//g; $s =~ s/&amp;/&/g; $s =~ s/&rsquo;/\x{e2}\x{80}\x{99}/g; $s =~ s/&nbsp;/ /g; $s =~ s/\s+/ /g; $s =~ s/^ | $//g; $s =~ s/\\/\\\\/g; $s =~ s/"/\\"/g; return $s; }

sub hero_form {
  my ($svc) = @_;
  my $opts = join '', map { my $sel = ($_ eq $svc) ? ' selected' : ''; "<option$sel>$_</option>" } @services;
  return <<EOF;
    <aside class="hero__form" id="enquire" aria-labelledby="hf-title">
      <form class="card-form" data-form novalidate>
        <div class="card-form__head">
          <p class="tag tag--light">Enquire online</p>
          <h2 id="hf-title">Request an appointment or ask a question</h2>
          <p>Our Chermside team will get back to you. For urgent medical help, call 000.</p>
        </div>
        <div class="field"><label for="hf-name">Full name</label><input id="hf-name" name="name" type="text" autocomplete="name" required></div>
        <div class="field-row">
          <div class="field"><label for="hf-phone">Phone</label><input id="hf-phone" name="phone" type="tel" autocomplete="tel" required></div>
          <div class="field"><label for="hf-email">Email</label><input id="hf-email" name="email" type="email" autocomplete="email" required></div>
        </div>
        <div class="field"><label for="hf-service">I&rsquo;m interested in</label><select id="hf-service" name="service">$opts</select></div>
        <button class="btn btn--signal btn--block btn--lg" type="submit">Send enquiry</button>
        <p class="form-note">By submitting this form, you acknowledge the BDYCULTURE <a href="privacy-policy.html">Privacy Policy</a>. Please do not include sensitive medical or health information in this form.</p>
        <p class="card-form__alt">Prefer to book yourself? <a href="$NOOKAL" target="_blank" rel="noopener">Book Online with Nookal &rarr;</a></p>
        <div class="form-ok" role="status" hidden>
          <span class="form-ok__dot" aria-hidden="true"></span>
          <h3>Thanks &mdash; enquiry received</h3>
          <p>We&rsquo;ll be in touch shortly. To speak to someone now, call <a href="tel:0730731616">07 3073 1616</a>.</p>
        </div>
      </form>
    </aside>
EOF
}

sub licence_form {
  return <<EOF;
    <aside class="hero__form" id="enquire" aria-labelledby="hf-title">
      <form class="card-form" data-form novalidate>
        <div class="card-form__head">
          <p class="tag tag--light">Licence enquiry</p>
          <h2 id="hf-title">Interested in Practising from BDYCULTURE?</h2>
          <p>Tell us a little about your profession, current practice and what you&rsquo;re looking for. We&rsquo;ll get in touch to discuss whether BDYCULTURE could be a good fit for your practice.</p>
        </div>
        <div class="field-row">
          <div class="field"><label for="hf-first">First name</label><input id="hf-first" name="first" type="text" autocomplete="given-name" required></div>
          <div class="field"><label for="hf-last">Last name</label><input id="hf-last" name="last" type="text" autocomplete="family-name" required></div>
        </div>
        <div class="field"><label for="hf-prof">Profession / Discipline</label><input id="hf-prof" name="profession" type="text" required></div>
        <div class="field-row">
          <div class="field"><label for="hf-email">Email</label><input id="hf-email" name="email" type="email" autocomplete="email" required></div>
          <div class="field"><label for="hf-phone">Phone</label><input id="hf-phone" name="phone" type="tel" autocomplete="tel" required></div>
        </div>
        <div class="field"><label for="hf-need">What are you looking for?</label><input id="hf-need" name="need" type="text" required></div>
        <button class="btn btn--signal btn--block btn--lg" type="submit">Enquire About a Licence</button>
        <p class="form-note">By submitting this form, you acknowledge our <a href="privacy-policy.html">Privacy Policy</a>.</p>
        <div class="form-ok" role="status" hidden>
          <span class="form-ok__dot" aria-hidden="true"></span>
          <h3>Thanks &mdash; enquiry received</h3>
          <p>We&rsquo;ll be in touch to discuss the fit. To speak to someone now, call <a href="tel:0730731616">07 3073 1616</a>.</p>
        </div>
      </form>
    </aside>
EOF
}

my @pages = grep { !/^index\.html$/ } glob('src/*.html');
for my $src (@pages) {
  open my $f, '<:raw', $src or die $!; my $raw = <$f>; close $f;
  my ($fm, $body) = $raw =~ m{\A(.*?)\n---\n(.*)\z}s or die "front matter in $src";
  my %m; for my $line (split /\n/, $fm) { next unless $line =~ /^(\w+):\s*(.*)$/; $m{$1} = $2; }
  (my $out = $src) =~ s{^src/}{};

  # breadcrumbs
  my @crumbs = split /\s*,\s*/, ($m{crumbs} || '');
  my ($crumb_html, @bc) = ('<a href="index.html">Home</a>');
  push @bc, '{"@type":"ListItem","position":1,"name":"Home","item":"index.html"}';
  my $pos = 1;
  for my $c (@crumbs) {
    my ($label, $href) = split /=/, $c; $pos++;
    $crumb_html .= $href ? qq{ <span aria-hidden="true">/</span> <a href="$href">$label</a>} : qq{ <span aria-hidden="true">/</span> <span aria-current="page">$label</span>};
    push @bc, sprintf('{"@type":"ListItem","position":%d,"name":"%s"%s}', $pos, jesc($label), $href ? qq{,"item":"$href"} : '');
  }

  # hero
  my $hero;
  my $lic = ($m{form} && $m{form} eq "licence");
  my $btns = $lic ? qq{<a class="btn btn--signal btn--lg" href="#enquire" data-focus-form>Enquire About a Licence <span aria-hidden="true">&rarr;</span></a>
        <a class="btn btn--ghost btn--lg" href="$NOOKAL" target="_blank" rel="noopener">Book Online</a>} :
   $m{hero} && $m{hero} eq 'none'
    ? qq{<a class="btn btn--signal btn--lg" href="$NOOKAL" target="_blank" rel="noopener">Book Online <span aria-hidden="true">&rarr;</span></a>\n        <a class="btn btn--call btn--lg" href="tel:0730731616">Call 07 3073 1616</a>\n        <a class="btn btn--ghost btn--lg" href="mailto:hello\@bdyculture.com.au">Email the clinic</a>}
    : qq{<a class="btn btn--signal btn--lg" href="$NOOKAL" target="_blank" rel="noopener">Book Online <span aria-hidden="true">&rarr;</span></a>\n        <a class="btn btn--call btn--lg" href="tel:0730731616">Call 07 3073 1616</a>\n        <a class="btn btn--ghost btn--lg hero__refer" href="referrers.html">Refer a Patient</a>};
  my $checks = $m{checks} || 'Online booking via Nookal|Physio &middot; Exercise Physiology &middot; OT &middot; Pilates|Home visits by arrangement';
  my $checks_html = join '', map { "<li>$_</li>" } split /\|/, $checks;
  my $form = ($m{hero} && $m{hero} eq "none") ? "" : ($m{form} && $m{form} eq "licence") ? licence_form() : hero_form($m{service} || "Physiotherapy");
  my $cls = ($m{hero} && $m{hero} eq 'none') ? 'hero hero--inner hero--noform' : 'hero hero--inner';
  $hero = <<EOF;
<section class="$cls" aria-labelledby="hero-title">
  <div class="wrap hero__grid">
    <div class="hero__copy">
      <nav class="crumbs" aria-label="Breadcrumb">$crumb_html</nav>
      <h1 id="hero-title">$m{h1}</h1>
      <p class="lead">$m{intro}</p>
      <div class="hero__btns">
        $btns
      </div>
      <ul class="hero__checks">$checks_html</ul>
    </div>
$form  </div>
</section>
EOF

  # FAQ schema from <details> blocks
  my @faq;
  while ($body =~ m{<details[^>]*>\s*<summary>(.*?)</summary>\s*<div>(.*?)</div>\s*</details>}sg) {
    push @faq, sprintf('{"@type":"Question","name":"%s","acceptedAnswer":{"@type":"Answer","text":"%s"}}', jesc($1), jesc($2));
  }
  my $ld = sprintf('{"@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[%s]}', join(',', @bc));
  my $scripts = qq{<script type="application/ld+json">$ld</script>\n};
  $scripts .= sprintf(qq{<script type="application/ld+json">{"\@context":"https://schema.org","\@type":"FAQPage","mainEntity":[%s]}</script>\n}, join(',', @faq)) if @faq;
  if ($m{service_name}) {
    $scripts .= sprintf(qq{<script type="application/ld+json">{"\@context":"https://schema.org","\@type":"Service","name":"%s","provider":{"\@type":"MedicalClinic","name":"BDYCULTURE Rehab & Performance Clinic","telephone":"+61730731616","address":{"\@type":"PostalAddress","streetAddress":"671 Gympie Road, Suite 5, Level 1","addressLocality":"Chermside","addressRegion":"QLD","postalCode":"4032","addressCountry":"AU"}},"areaServed":"Chermside, Brisbane"}</script>\n}, jesc($m{service_name}));
  }
  if ($m{article}) {
    $scripts .= sprintf(qq{<script type="application/ld+json">{"\@context":"https://schema.org","\@type":"BlogPosting","headline":"%s","author":{"\@type":"Organization","name":"BDYCULTURE"},"publisher":{"\@type":"Organization","name":"BDYCULTURE Rehab & Performance Clinic"}}</script>\n}, jesc($m{h1}));
  }

  # header: current-page state + contact-page enquire target
  my $h = $header;
  $h =~ s{(<a href="index.html")\s+aria-current="page"}{$1};
  my $nav = $m{nav} || '';
  if    ($nav eq 'services')  { $h =~ s{(<a href="services.html" class="nav__dd-trigger")}{$1 aria-current="page"}; }
  elsif ($nav eq 'referrers') { $h =~ s{(<a href="referrers.html">Referrers</a>)}{<a href="referrers.html" aria-current="page">Referrers</a>}; }
  elsif ($nav eq 'contact')   { $h =~ s{(<a href="contact.html">Contact</a>\n    </nav>)}{<a href="contact.html" aria-current="page">Contact</a>\n    </nav>}; }
  $h =~ s{href="#contact"(\s+data-focus-form)}{href="#enquire"$1}g unless $m{hero} && $m{hero} eq "none";
  $h =~ s{href="#enquire"}{href="#contact"}g if $m{hero} && $m{hero} eq 'none';

  my $head = <<EOF;
<!doctype html>
<html lang="en-AU">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>$m{title}</title>
<meta name="description" content="$m{desc}">
<link rel="icon" href="images/logo-mark-black.png" type="image/png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght\@400;500&family=Host+Grotesk:wght\@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/inner.css">
$scripts</head>
<body class="inner">
EOF

  open my $o, '>:raw', $out or die $!;
  print $o $head, $h, "<main id=\"main\">\n\n", $hero, "\n", $body, "\n", $tail, "</main>", $after;
  close $o;
  print "built $out\n";
}
